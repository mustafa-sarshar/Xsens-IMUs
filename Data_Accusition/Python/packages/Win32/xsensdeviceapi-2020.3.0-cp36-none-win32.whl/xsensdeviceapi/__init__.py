#!/usr/bin/env python
import os
import sys
here = os.path.dirname(os.path.realpath(__file__))
sys.path.append(here)
from xsensdeviceapi_py36_32 import *
